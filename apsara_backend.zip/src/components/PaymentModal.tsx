export { default } from './KHQRPaymentModal';
